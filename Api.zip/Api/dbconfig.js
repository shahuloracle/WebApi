const  config = {
    user:  'sa', // sql user
    password:  'VesselFresh123', //sql user password
    server:  '10.201.152.8', // if it does not work try- localhost
    database:  'PAL',
    options: {
      trustedconnection:  true,
      enableArithAbort:  true,
      instancename:  'SQLEXPRESS'  // SQL Server instance name
    },
    port:  1433
  }
  
  module.exports = config;