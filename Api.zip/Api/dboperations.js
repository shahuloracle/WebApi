var  config = require('./dbconfig');
var  _output = require('./default/data');
var  _tables = require('./default/createTable');
const  sql = require('mssql');


  async  function  getAdminStructures(code) {
    try {

      let output = new _output(null,null,null);

      let  pool = await  sql.connect(config);
       await  pool.request()
       .input('OPERATION_TYPE','SEL')
       .input('RECORD_TYPE',code)
       .execute('[Purchase].[Up_SP_Admin_StructureS]').
       then((res)=>{ 
        output.isSuccess = true;
        output.data = res.recordsets[0];
      }).catch((error)=>{
        output.isSuccess = false;
        output.message = 'Something went to wrong...';

      });
      return  output;
    }
    catch (error) {
      console.log(error);
    }
  }


  


  async function saveAdmin(req)
  {
    
   let output = new _output(null,null,null);

    
    let  pool = await  sql.connect(config);

    const table = new  _tables.adminType();

    req.body.pAdminDataList.map(x=> {
      table.rows.add(x.recordType,x.code,x.name,x.active==true?'Y':'N' , 1982,x.sortOrder);
    })

     await pool.request()
      .input('P_DATA', table)
      .input('RECORD_TYPE', req.body.reqType)
      .execute('[Purchase].[Up_SP_Admin_StructureS]').then((response)=>
      {
        output.isSuccess = true;
        output.data = response.recordsets[0];
      })
      .catch(error=> {
        output.isSuccess = false;
        output.message =error.message;
      });

      return output;

  }


  module.exports = {
    getAdminStructures: getAdminStructures,
    saveAdmin: saveAdmin
  }