const sql = require('mssql');

function adminType() {
  const table = new sql.Table();
  table.columns.add('RECORD_TYPE', sql.NVarChar(10));
  table.columns.add('CODE', sql.NVarChar(50));
  table.columns.add('NAME', sql.NVarChar(500));
  table.columns.add('ACTIVE', sql.NVarChar(10));
  table.columns.add('MODIFIED_BY_ID', sql.BigInt);
  table.columns.add('SORT_ORDER', sql.BigInt);
  return table;
}


function admindtType() {
    const table = new sql.Table();
    table.columns.add('RECORD_TYPE', sql.NVarChar(10));
    table.columns.add('CODE', sql.NVarChar(50));
    table.columns.add('NAME', sql.NVarChar(500));
    table.columns.add('ACTIVE', sql.NVarChar(10));
    table.columns.add('MODIFIED_BY_ID', sql.BigInt);
    table.columns.add('SORT_ORDER', sql.BigInt);
    return table;
  }

module.exports = { 
    
    adminType:adminType ,
    admindtType:admindtType

};